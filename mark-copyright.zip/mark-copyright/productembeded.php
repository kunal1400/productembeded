<style>
	html {
		margin-top: 0 !important;
	}
	#wpadminbar {
		display: none;
	}
</style>
<?php 
// wp_head();
if ( have_posts() ) {
	while ( have_posts() ) {
		the_post(); 
		the_content();
	}
}
// wp_footer();